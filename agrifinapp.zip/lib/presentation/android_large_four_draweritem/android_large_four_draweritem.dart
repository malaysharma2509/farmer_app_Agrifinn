import 'package:flutter/material.dart';
import 'package:kartikay_s_application7/core/app_export.dart';

// ignore_for_file: must_be_immutable
class AndroidLargeFourDraweritem extends StatelessWidget {
  const AndroidLargeFourDraweritem({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        width: 249.h,
        padding: EdgeInsets.symmetric(vertical: 16.v),
        decoration: AppDecoration.fillLime,
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 9.h,
                  right: 65.h,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.img1096181,
                      height: 29.v,
                      width: 35.h,
                      margin: EdgeInsets.only(bottom: 90.v),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgDownload1,
                      height: 100.v,
                      width: 118.h,
                      radius: BorderRadius.circular(
                        50.h,
                      ),
                      margin: EdgeInsets.only(
                        left: 22.h,
                        top: 19.v,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 7.v),
            CustomImageView(
              imagePath: ImageConstant.imgScreenshot20240316,
              height: 23.v,
              width: 96.h,
            ),
            SizedBox(height: 40.v),
            _buildTwenty(
              context,
              image: ImageConstant.imgImages1,
              pendingApprovals: "Contact Details",
            ),
            SizedBox(height: 19.v),
            _buildTwenty(
              context,
              image: ImageConstant.imgNotepadIconVector16897435,
              pendingApprovals: "Pending Approvals",
            ),
            SizedBox(height: 19.v),
            _buildFifteen(
              context,
              downloadFour: ImageConstant.imgDownload2,
              editProfiles: "Current Purchases",
            ),
            SizedBox(height: 19.v),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 13.h,
                vertical: 1.v,
              ),
              decoration: AppDecoration.fillPrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder16,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgDownload3,
                    height: 27.v,
                    width: 25.h,
                    margin: EdgeInsets.only(bottom: 4.v),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 8.h,
                      top: 4.v,
                      bottom: 2.v,
                    ),
                    child: Text(
                      "Payments",
                      style: CustomTextStyles.titleLargeInriaSerif,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 19.v),
            _buildFifteen(
              context,
              downloadFour: ImageConstant.imgDownload4,
              editProfiles: "Edit Profiles",
            ),
            SizedBox(height: 19.v),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 13.h,
                vertical: 1.v,
              ),
              decoration: AppDecoration.fillPrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder16,
              ),
              child: Row(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgDownload5,
                    height: 19.v,
                    width: 23.h,
                    margin: EdgeInsets.symmetric(vertical: 5.v),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 10.h,
                      top: 5.v,
                    ),
                    child: Text(
                      "Settings",
                      style: CustomTextStyles.titleLargeInriaSerif,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 19.v),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 17.h,
                vertical: 3.v,
              ),
              decoration: AppDecoration.fillPrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder16,
              ),
              child: Row(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgDownload6,
                    height: 22.adaptSize,
                    width: 22.adaptSize,
                    margin: EdgeInsets.only(
                      top: 1.v,
                      bottom: 2.v,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 8.h,
                      top: 1.v,
                    ),
                    child: Text(
                      "Helpdesk",
                      style: CustomTextStyles.titleLargeInriaSerif,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 19.v),
            _buildTwenty(
              context,
              image: ImageConstant.imgDownload7,
              pendingApprovals: "LogOut",
            ),
            SizedBox(height: 19.v),
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildTwenty(
    BuildContext context, {
    required String image,
    required String pendingApprovals,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 4.v,
      ),
      decoration: AppDecoration.fillPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder16,
      ),
      child: Row(
        children: [
          CustomImageView(
            imagePath: image,
            height: 21.v,
            width: 26.h,
            margin: EdgeInsets.symmetric(vertical: 1.v),
          ),
          Padding(
            padding: EdgeInsets.only(left: 7.h),
            child: Text(
              pendingApprovals,
              style: CustomTextStyles.titleLargeInriaSerif.copyWith(
                color: theme.colorScheme.errorContainer,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildFifteen(
    BuildContext context, {
    required String downloadFour,
    required String editProfiles,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 10.h,
        vertical: 1.v,
      ),
      decoration: AppDecoration.fillPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder16,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: downloadFour,
            height: 30.v,
            width: 33.h,
            margin: EdgeInsets.only(bottom: 1.v),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 2.h,
              top: 3.v,
              bottom: 3.v,
            ),
            child: Text(
              editProfiles,
              style: CustomTextStyles.titleLargeInriaSerif.copyWith(
                color: theme.colorScheme.errorContainer,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
