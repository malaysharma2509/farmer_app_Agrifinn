import 'package:kartikay_s_application7/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:kartikay_s_application7/core/app_export.dart';

class AndroidLargeOneOneScreen extends StatelessWidget {
  const AndroidLargeOneOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onPrimary,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgIstockphoto118,
                height: 459.v,
                width: 360.h,
                radius: BorderRadius.circular(
                  65.h,
                ),
              ),
              SizedBox(height: 41.v),
              CustomElevatedButton(
                text: "Login  as existing user",
                margin: EdgeInsets.only(
                  left: 43.h,
                  right: 42.h,
                ),
                buttonStyle: CustomButtonStyles.fillGrayE,
              ),
              SizedBox(height: 20.v),
              Text(
                "or",
                style: CustomTextStyles.headlineLargeInterGray900,
              ),
              SizedBox(height: 16.v),
              CustomElevatedButton(
                text: "Sign up/Create New Account",
                margin: EdgeInsets.only(
                  left: 43.h,
                  right: 42.h,
                ),
                buttonStyle: CustomButtonStyles.fillBlack,
              ),
              SizedBox(height: 21.v),
              CustomImageView(
                imagePath: ImageConstant.imgScreenshot20240315,
                height: 43.v,
                width: 225.h,
                radius: BorderRadius.circular(
                  21.h,
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }
}
