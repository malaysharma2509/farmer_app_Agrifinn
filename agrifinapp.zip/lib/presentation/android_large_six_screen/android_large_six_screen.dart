import 'package:kartikay_s_application7/widgets/custom_elevated_button.dart';
import 'widgets/androidlargesix_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:kartikay_s_application7/core/app_export.dart';

class AndroidLargeSixScreen extends StatelessWidget {
  const AndroidLargeSixScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.lime50,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTwentyEight(context),
              SizedBox(height: 11.v),
              _buildFiftyThree(context),
              SizedBox(height: 10.v),
              SizedBox(
                height: 587.v,
                width: double.maxFinite,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 22.h,
                          right: 262.h,
                          bottom: 2.v,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgDownload12,
                              height: 35.v,
                              width: 42.h,
                            ),
                            SizedBox(height: 5.v),
                            Text(
                              "Reminders",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ),
                    _buildAndroidLargeSix(context),
                  ],
                ),
              ),
              SizedBox(height: 3.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildTwentyEight(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(
        horizontal: 5.h,
        vertical: 32.v,
      ),
      decoration: AppDecoration.fillLime800.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder40,
      ),
      child: Text(
        "Dashboard",
        style: theme.textTheme.headlineLarge,
      ),
    );
  }

  /// Section Widget
  Widget _buildFiftyThree(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 13.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          SizedBox(
            height: 74.v,
            width: 276.h,
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: EdgeInsets.only(left: 8.h),
                    child: Text(
                      "Hello! RamPrasad",
                      style: theme.textTheme.headlineSmall,
                    ),
                  ),
                ),
                CustomElevatedButton(
                  height: 46.v,
                  width: 276.h,
                  text: "Join Our Farmers Community Today",
                  buttonStyle: CustomButtonStyles.fillErrorContainer,
                  buttonTextStyle: CustomTextStyles.bodyMediumInter,
                  alignment: Alignment.bottomCenter,
                ),
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgDownload16,
            height: 32.v,
            width: 31.h,
            margin: EdgeInsets.only(
              top: 31.v,
              bottom: 11.v,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgDownload17,
            height: 36.v,
            width: 34.h,
            margin: EdgeInsets.only(
              left: 6.h,
              top: 27.v,
              bottom: 11.v,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAndroidLargeSix(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 174.v,
          crossAxisCount: 2,
          mainAxisSpacing: 1.h,
          crossAxisSpacing: 1.h,
        ),
        physics: NeverScrollableScrollPhysics(),
        itemCount: 9,
        itemBuilder: (context, index) {
          return AndroidlargesixItemWidget();
        },
      ),
    );
  }
}
