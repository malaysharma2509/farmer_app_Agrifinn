import 'package:flutter/material.dart';
import 'package:kartikay_s_application7/core/app_export.dart';

// ignore: must_be_immutable
class AndroidlargesixItemWidget extends StatelessWidget {
  const AndroidlargesixItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 4.h,
          vertical: 16.v,
        ),
        decoration: AppDecoration.outlinePrimaryContainer,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 21.v),
            CustomImageView(
              imagePath: ImageConstant.imgDownload8,
              height: 90.v,
              width: 102.h,
              alignment: Alignment.center,
            ),
            Text(
              "Available Lenders",
              style: CustomTextStyles.bodyLargeInriaSerifPrimaryContainer,
            ),
          ],
        ),
      ),
    );
  }
}
